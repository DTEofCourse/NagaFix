package com.dte.nagafix.mixin;

import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = Entity.class, priority = 1500)
public class NagaFixMixin {
    @Dynamic
    @Inject(
            method = {
                    "handler$*$apoli$preventPhasingSuffocation"}, at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void skipNagaCrash(CallbackInfo ci) {
        Entity entity = (Entity) (Object) this;
        if (entity.getType().toString().contains("naga")) {
            ci.cancel();
        }
    }
}
